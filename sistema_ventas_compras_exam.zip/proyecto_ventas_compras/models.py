"""Modelos de ventas y compras: abstracción, herencia, encapsulamiento y composición."""
from abc import ABC, abstractmethod
from datetime import date
from math import isfinite


class ModeloBase(ABC):
    CAMPOS = ()
    OBLIGATORIOS = ()

    def __init__(self, id_registro):
        self.__id = int(id_registro)
        if self.__id <= 0:
            raise ValueError('ID inválido')

    @property
    def id(self):
        return self.__id

    @staticmethod
    def limpiar(texto):
        return str(texto).strip()

    @abstractmethod
    def a_diccionario(self):
        pass

    @abstractmethod
    def etiqueta(self):
        pass

    @classmethod
    def desde_diccionario(cls, datos):
        valores = {campo: datos.get(campo, '') for campo in cls.CAMPOS}
        return cls(datos['id'], **valores)

    def __str__(self):
        return f'[{self.id}] {self.etiqueta()}'


class Persona(ModeloBase):
    CAMPOS = ('nombre', 'apellido', 'email')
    OBLIGATORIOS = CAMPOS

    def __init__(self, id_registro, nombre, apellido, email):
        super().__init__(id_registro)
        self.nombre, self.apellido, self.email = nombre, apellido, email

    @staticmethod
    def es_email_valido(texto):
        texto = str(texto).strip()
        if texto.count('@') != 1:
            return False
        usuario, dominio = texto.split('@')
        return bool(usuario) and '.' in dominio and not dominio.startswith('.') and not dominio.endswith('.')

    @property
    def nombre(self):
        return self.__nombre

    @nombre.setter
    def nombre(self, valor):
        valor = self.limpiar(valor)
        if not valor:
            raise ValueError('El nombre es obligatorio')
        self.__nombre = valor.title()

    @property
    def apellido(self):
        return self.__apellido

    @apellido.setter
    def apellido(self, valor):
        valor = self.limpiar(valor)
        if not valor:
            raise ValueError('El apellido es obligatorio')
        self.__apellido = valor.title()

    @property
    def email(self):
        return self.__email

    @email.setter
    def email(self, valor):
        valor = self.limpiar(valor)
        if not self.es_email_valido(valor):
            raise ValueError('Email inválido')
        self.__email = valor.lower()

    @property
    def nombre_completo(self):
        return f'{self.nombre} {self.apellido}'

    def a_diccionario(self):
        return {'id': self.id, 'nombre': self.nombre, 'apellido': self.apellido, 'email': self.email}


class Cliente(Persona):
    CAMPOS = Persona.CAMPOS + ('telefono', 'ciudad')
    OBLIGATORIOS = Persona.OBLIGATORIOS

    def __init__(self, id_registro, nombre, apellido, email, telefono='', ciudad=''):
        super().__init__(id_registro, nombre, apellido, email)
        self.telefono, self.ciudad = telefono, ciudad

    @property
    def telefono(self):
        return self.__telefono

    @telefono.setter
    def telefono(self, valor):
        valor = self.limpiar(valor)
        if valor and not valor.isdigit():
            raise ValueError('Teléfono solo admite números')
        self.__telefono = valor

    @property
    def ciudad(self):
        return self.__ciudad

    @ciudad.setter
    def ciudad(self, valor):
        self.__ciudad = self.limpiar(valor).title()

    def a_diccionario(self):
        d = super().a_diccionario()
        d.update(telefono=self.telefono, ciudad=self.ciudad)
        return d

    def etiqueta(self):
        return f'{self.nombre_completo} · {self.email}'


class Proveedor(Persona):
    CAMPOS = Persona.CAMPOS + ('ruc', 'empresa')
    OBLIGATORIOS = Persona.OBLIGATORIOS + ('ruc',)

    def __init__(self, id_registro, nombre, apellido, email, ruc='', empresa=''):
        super().__init__(id_registro, nombre, apellido, email)
        self.ruc, self.empresa = ruc, empresa

    @property
    def ruc(self):
        return self.__ruc

    @ruc.setter
    def ruc(self, valor):
        valor = self.limpiar(valor)
        if len(valor) != 13 or not valor.isdigit():
            raise ValueError('El RUC debe tener 13 números')
        self.__ruc = valor

    @property
    def empresa(self):
        return self.__empresa

    @empresa.setter
    def empresa(self, valor):
        self.__empresa = self.limpiar(valor).title()

    def a_diccionario(self):
        d = super().a_diccionario()
        d.update(ruc=self.ruc, empresa=self.empresa)
        return d

    def etiqueta(self):
        return f'{self.empresa or "Sin empresa"} · {self.nombre_completo} · RUC {self.ruc}'


class Producto(ModeloBase):
    CAMPOS = ('nombre', 'precio', 'stock')
    OBLIGATORIOS = ('nombre', 'precio')

    def __init__(self, id_registro, nombre, precio, stock=0):
        super().__init__(id_registro)
        self.nombre, self.precio, self.stock = nombre, precio, stock

    @property
    def nombre(self):
        return self.__nombre

    @nombre.setter
    def nombre(self, valor):
        valor = self.limpiar(valor)
        if not valor:
            raise ValueError('Nombre de producto obligatorio')
        self.__nombre = valor.title()

    @property
    def precio(self):
        return self.__precio

    @precio.setter
    def precio(self, valor):
        try:
            valor = float(valor)
        except (TypeError, ValueError):
            raise ValueError('Precio inválido')
        if not isfinite(valor) or valor <= 0:
            raise ValueError('El precio debe ser positivo y finito')
        self.__precio = round(valor, 2)

    @property
    def stock(self):
        return self.__stock

    @stock.setter
    def stock(self, valor):
        try:
            n = int(valor)
        except (ValueError, TypeError):
            raise ValueError('El stock debe ser entero')
        if n < 0 or str(valor).strip() not in (str(n),):
            raise ValueError('El stock debe ser un entero no negativo')
        self.__stock = n

    @property
    def disponible(self):
        return self.stock > 0

    def hay_stock(self, cantidad):
        return isinstance(cantidad, int) and 0 < cantidad <= self.stock

    def descontar_stock(self, cantidad):
        if not self.hay_stock(cantidad):
            raise ValueError(f'Stock insuficiente de {self.nombre}: quedan {self.stock}')
        self.__stock -= cantidad

    def aumentar_stock(self, cantidad):
        """NUEVO - Examen 13: compras suman al stock."""
        if not isinstance(cantidad, int) or cantidad <= 0:
            raise ValueError('La cantidad comprada debe ser un entero positivo')
        self.__stock += cantidad

    def a_diccionario(self):
        return {'id': self.id, 'nombre': self.nombre, 'precio': self.precio, 'stock': self.stock}

    def etiqueta(self):
        return f'{self.nombre} · ${self.precio:.2f} · stock {self.stock}'


class DetalleBase:
    """Ayuda interna para validar detalles sin duplicar lógica."""
    def __init__(self, producto_id, descripcion, cantidad, precio):
        self.__producto_id = int(producto_id)
        self.__descripcion = str(descripcion)
        self.cantidad, self._precio = cantidad, self._validar_precio(precio)

    @staticmethod
    def _validar_precio(valor):
        try:
            n = float(valor)
        except (ValueError, TypeError):
            raise ValueError('El precio/costo debe ser numérico')
        if not isfinite(n) or n <= 0:
            raise ValueError('El precio/costo debe ser mayor que cero')
        return round(n, 2)

    @property
    def cantidad(self):
        return self.__cantidad

    @cantidad.setter
    def cantidad(self, valor):
        if isinstance(valor, bool) or not str(valor).isdigit() or int(valor) <= 0:
            raise ValueError('La cantidad debe ser entero positivo')
        self.__cantidad = int(valor)

    @property
    def producto_id(self):
        return self.__producto_id

    @property
    def descripcion(self):
        return self.__descripcion

    @property
    def subtotal(self):
        return round(self.cantidad * self._precio, 2)


class DetalleVenta(DetalleBase):
    @property
    def precio_unitario(self):
        return self._precio

    def a_diccionario(self):
        return dict(producto_id=self.producto_id, descripcion=self.descripcion, cantidad=self.cantidad,
                    precio_unitario=self.precio_unitario, subtotal=self.subtotal)

    @classmethod
    def desde_diccionario(cls, d):
        return cls(d['producto_id'], d['descripcion'], d['cantidad'], d['precio_unitario'])

    def __str__(self):
        return f'{self.cantidad} x {self.descripcion} a ${self.precio_unitario:.2f} = ${self.subtotal:.2f}'


class DetalleCompra(DetalleBase):
    @property
    def costo_unitario(self):
        return self._precio

    def a_diccionario(self):
        return dict(producto_id=self.producto_id, descripcion=self.descripcion, cantidad=self.cantidad,
                    costo_unitario=self.costo_unitario, subtotal=self.subtotal)

    @classmethod
    def desde_diccionario(cls, d):
        return cls(d['producto_id'], d['descripcion'], d['cantidad'], d['costo_unitario'])

    def __str__(self):
        return f'{self.cantidad} x {self.descripcion} a ${self.costo_unitario:.2f} = ${self.subtotal:.2f}'


class Venta(ModeloBase):
    CAMPOS = ('cliente_id', 'fecha')
    OBLIGATORIOS = ('cliente_id',)

    def __init__(self, id_registro, cliente_id, fecha='', detalles=None):
        super().__init__(id_registro)
        self.cliente_id = int(cliente_id)
        self.fecha = fecha or date.today().isoformat()
        self.__detalles = list(detalles) if detalles else []

    @property
    def detalles(self):
        return tuple(self.__detalles)

    @property
    def total(self):
        return round(sum(d.subtotal for d in self.__detalles), 2)

    @property
    def cantidad_items(self):
        return sum(d.cantidad for d in self.__detalles)

    def agregar_detalle(self, producto, cantidad):
        if not producto.hay_stock(cantidad):
            raise ValueError('Stock insuficiente')
        detalle = DetalleVenta(producto.id, producto.nombre, cantidad, producto.precio)
        self.__detalles.append(detalle)

    def a_diccionario(self):
        return dict(id=self.id, cliente_id=self.cliente_id, fecha=self.fecha, total=self.total,
                    detalles=[d.a_diccionario() for d in self.__detalles])

    @classmethod
    def desde_diccionario(cls, d):
        return cls(d['id'], d['cliente_id'], d.get('fecha', ''),
                   [DetalleVenta.desde_diccionario(x) for x in d.get('detalles', [])])

    def etiqueta(self):
        return f'Venta del {self.fecha} · cliente {self.cliente_id} · {len(self.__detalles)} ítem(s) · ${self.total:.2f}'


class Compra(ModeloBase):
    CAMPOS = ('proveedor_id', 'fecha')
    OBLIGATORIOS = ('proveedor_id',)

    def __init__(self, id_registro, proveedor_id, fecha='', detalles=None):
        super().__init__(id_registro)
        self.proveedor_id = int(proveedor_id)
        self.fecha = fecha or date.today().isoformat()
        self.__detalles = list(detalles) if detalles else []

    @property
    def detalles(self):
        return tuple(self.__detalles)

    @property
    def total(self):
        return round(sum(d.subtotal for d in self.__detalles), 2)

    @property
    def cantidad_items(self):
        return sum(d.cantidad for d in self.__detalles)

    def agregar_detalle(self, producto, cantidad, costo_unitario):
        self.__detalles.append(DetalleCompra(producto.id, producto.nombre, cantidad, costo_unitario))

    def a_diccionario(self):
        return dict(id=self.id, proveedor_id=self.proveedor_id, fecha=self.fecha, total=self.total,
                    detalles=[d.a_diccionario() for d in self.__detalles])

    @classmethod
    def desde_diccionario(cls, d):
        return cls(d['id'], d['proveedor_id'], d.get('fecha', ''),
                   [DetalleCompra.desde_diccionario(x) for x in d.get('detalles', [])])

    def etiqueta(self):
        return f'Compra del {self.fecha} · proveedor {self.proveedor_id} · {len(self.__detalles)} ítem(s) · ${self.total:.2f}'
