"""Controladores del sistema: las operaciones CRUD y reglas del negocio."""
from abc import ABC, abstractmethod
from models import Cliente, Proveedor, Producto, Venta, Compra
from shared.json_manager import GestorJSON


class CrudBase(ABC):
    @abstractmethod
    def leer(self): pass
    @abstractmethod
    def buscar(self, texto): pass
    @abstractmethod
    def siguiente(self): pass
    @abstractmethod
    def crear(self, datos): pass
    @abstractmethod
    def actualizar(self, id_registro, datos): pass
    @abstractmethod
    def eliminar(self, id_registro): pass


class ControladorComun(CrudBase):
    """Implementación compartida del CRUD; cada clase define su MODELO y ARCHIVO."""
    MODELO = None
    ARCHIVO = ''
    nombre = ''

    def __init__(self, archivo=None):
        self.campos = self.MODELO.CAMPOS
        self.gestor = GestorJSON(archivo or self.ARCHIVO)
        self.lista = [self.MODELO.desde_diccionario(x) for x in self.gestor.leer()]

    def guardar(self):
        self.gestor.guardar([x.a_diccionario() for x in self.lista])

    def leer(self):
        return self.lista

    def obtener(self, id_registro):
        return next((x for x in self.lista if x.id == id_registro), None)

    def siguiente(self):
        return max((x.id for x in self.lista), default=0) + 1

    def buscar(self, texto):
        texto = str(texto).strip().lower()
        if not texto:
            return []
        return [objeto for objeto in self.lista
                if any(texto in str(objeto.a_diccionario().get(campo, '')).lower()
                       for campo in self.campos)]

    def _validar_unicos(self, datos, id_actual=None):
        return None

    def crear(self, datos):
        error = self._validar_unicos(datos)
        if error:
            return False, error
        try:
            objeto = self.MODELO(self.siguiente(), **datos)
        except (ValueError, TypeError) as error:
            return False, str(error)
        self.lista.append(objeto)
        self.guardar()
        return True, f'{self.nombre.capitalize()} creado: {objeto.etiqueta()}'

    def actualizar(self, id_registro, datos):
        viejo = self.obtener(id_registro)
        if viejo is None:
            return False, 'No existe ese registro'
        if not datos:
            return False, 'No se indicó ningún cambio'
        if set(datos) - set(self.campos):
            return False, 'Hay campos no permitidos'
        nuevos = {campo: getattr(viejo, campo) for campo in self.campos}
        nuevos.update(datos)
        error = self._validar_unicos(nuevos, id_registro)
        if error:
            return False, error
        try:
            nuevo = self.MODELO(id_registro, **nuevos)
        except (ValueError, TypeError) as error:
            return False, str(error)
        self.lista[self.lista.index(viejo)] = nuevo
        self.guardar()
        return True, f'{self.nombre.capitalize()} {id_registro} actualizado'

    def eliminar(self, id_registro):
        objeto = self.obtener(id_registro)
        if objeto is None:
            return False, 'No existe ese registro'
        self.lista.remove(objeto)
        self.guardar()
        return True, f'{self.nombre.capitalize()} {id_registro} eliminado'


class ClienteController(ControladorComun):
    MODELO, ARCHIVO, nombre = Cliente, 'data/clientes.json', 'cliente'

    def _validar_unicos(self, datos, id_actual=None):
        email = str(datos.get('email', '')).strip().lower()
        if any(x.email == email and x.id != id_actual for x in self.lista):
            return 'Ese email ya está registrado'


class ProveedorController(ControladorComun):
    """NUEVO - Examen 13: CRUD de proveedores; email y RUC únicos."""
    MODELO, ARCHIVO, nombre = Proveedor, 'data/proveedores.json', 'proveedor'

    def _validar_unicos(self, datos, id_actual=None):
        email = str(datos.get('email', '')).strip().lower()
        ruc = str(datos.get('ruc', '')).strip()
        if any(x.email == email and x.id != id_actual for x in self.lista):
            return 'Ese email ya está registrado'
        if any(x.ruc == ruc and x.id != id_actual for x in self.lista):
            return 'Ese RUC ya está registrado'


class ProductoController(ControladorComun):
    MODELO, ARCHIVO, nombre = Producto, 'data/productos.json', 'producto'

    def crear(self, datos):
        datos = dict(datos)
        if not str(datos.get('stock', '')).strip():
            datos['stock'] = 0
        return super().crear(datos)

    def _validar_unicos(self, datos, id_actual=None):
        nombre = str(datos.get('nombre', '')).strip().title()
        if any(x.nombre == nombre and x.id != id_actual for x in self.lista):
            return 'Ese producto ya está registrado'

    def descontar_stock(self, id_producto, cantidad):
        producto = self.obtener(id_producto)
        if producto is None:
            return False, 'Producto no encontrado'
        try:
            producto.descontar_stock(cantidad)
        except ValueError as error:
            return False, str(error)
        self.guardar()
        return True, f'Quedan {producto.stock}'

    def con_stock_bajo(self, minimo=5):
        return [x for x in self.lista if x.stock <= minimo]


class OperacionBase(ControladorComun):
    """Ventas y compras mantienen sus propios detalles y operaciones de stock."""
    def actualizar(self, id_registro, datos):
        return False, f'Las {self.nombre}s registradas no se pueden modificar'

    def buscar(self, texto):
        texto = str(texto).strip()
        return [x for x in self.lista if texto and texto in x.fecha]

    @staticmethod
    def _items_validos(items, productos):
        if not isinstance(items, list) or not items:
            return 'La operación debe tener al menos un producto'
        vistos = set()
        for item in items:
            if not isinstance(item, dict):
                return 'Formato de producto incorrecto'
            pid = item.get('producto_id')
            if not isinstance(pid, int):
                return 'ID de producto inválido'
            if pid in vistos:
                return f'Producto {pid} repetido en la operación'
            vistos.add(pid)
            if productos.obtener(pid) is None:
                return f'No existe producto con ID {pid}'
            cantidad = item.get('cantidad')
            if not isinstance(cantidad, int) or cantidad <= 0:
                return 'Cantidad debe ser un entero positivo'
        return None


class VentaController(OperacionBase):
    MODELO, ARCHIVO, nombre = Venta, 'data/ventas.json', 'venta'

    def __init__(self, clientes, productos, archivo=None):
        self.clientes, self.productos = clientes, productos
        super().__init__(archivo)

    def crear(self, datos):
        try:
            cliente_id = int(datos.get('cliente_id', 0))
        except (TypeError, ValueError):
            return False, 'ID de cliente inválido'
        if self.clientes.obtener(cliente_id) is None:
            return False, 'Cliente no encontrado'
        items = datos.get('items', [])
        error = self._items_validos(items, self.productos)
        if error:
            return False, error
        venta = Venta(self.siguiente(), cliente_id)
        for item in items:
            producto = self.productos.obtener(item['producto_id'])
            if not producto.hay_stock(item['cantidad']):
                return False, f'Stock insuficiente de {producto.nombre}'
            venta.agregar_detalle(producto, item['cantidad'])
        for item in items:
            self.productos.obtener(item['producto_id']).descontar_stock(item['cantidad'])
        self.productos.guardar()
        self.lista.append(venta)
        self.guardar()
        return True, f'Venta {venta.id} registrada por ${venta.total:.2f}'

    def eliminar(self, id_registro):
        venta = self.obtener(id_registro)
        if venta is None:
            return False, 'Venta no encontrada'
        # Al anular, devuelve las unidades vendidas al stock.
        for detalle in venta.detalles:
            if self.productos.obtener(detalle.producto_id) is None:
                return False, 'No se puede anular: producto eliminado'
        for detalle in venta.detalles:
            self.productos.obtener(detalle.producto_id).aumentar_stock(detalle.cantidad)
        self.productos.guardar()
        return super().eliminar(id_registro)

    def factura(self, id_venta):
        venta = self.obtener(id_venta)
        if venta is None:
            return None
        cliente = self.clientes.obtener(venta.cliente_id)
        texto = f'FACTURA #{venta.id}   fecha: {venta.fecha}\n'
        texto += f'Cliente: {cliente.nombre_completo if cliente else "Eliminado"}\n' + '-' * 45 + '\n'
        texto += '\n'.join('  ' + str(d) for d in venta.detalles)
        return texto + f'\n' + '-' * 45 + f'\nTOTAL: ${venta.total:.2f} ({venta.cantidad_items} ítems)'

    def ventas_de_cliente(self, cliente_id):
        return [x for x in self.lista if x.cliente_id == cliente_id]


class CompraController(OperacionBase):
    """NUEVO - Examen 13: compra primero valida todos los ítems y después sube el stock."""
    MODELO, ARCHIVO, nombre = Compra, 'data/compras.json', 'compra'

    def __init__(self, proveedores, productos, archivo=None):
        self.proveedores, self.productos = proveedores, productos
        super().__init__(archivo)

    def crear(self, datos):
        try:
            proveedor_id = int(datos.get('proveedor_id', 0))
        except (TypeError, ValueError):
            return False, 'ID de proveedor inválido'
        if self.proveedores.obtener(proveedor_id) is None:
            return False, 'Proveedor no encontrado'
        items = datos.get('items', [])
        error = self._items_validos(items, self.productos)
        if error:
            return False, error
        compra = Compra(self.siguiente(), proveedor_id)
        try:
            # Construir toda la compra ANTES de modificar el stock.
            for item in items:
                producto = self.productos.obtener(item['producto_id'])
                compra.agregar_detalle(producto, item['cantidad'], item.get('costo_unitario', ''))
        except (TypeError, ValueError) as error:
            return False, str(error)
        for detalle in compra.detalles:
            self.productos.obtener(detalle.producto_id).aumentar_stock(detalle.cantidad)
        self.productos.guardar()
        self.lista.append(compra)
        self.guardar()
        return True, f'Compra {compra.id} registrada por ${compra.total:.2f}'

    def eliminar(self, id_registro):
        compra = self.obtener(id_registro)
        if compra is None:
            return False, 'Compra no encontrada'
        # No puede dejar stock negativo al anular.
        for d in compra.detalles:
            producto = self.productos.obtener(d.producto_id)
            if producto is None or not producto.hay_stock(d.cantidad):
                return False, f'No se puede anular: stock insuficiente del producto {d.producto_id}'
        for d in compra.detalles:
            self.productos.obtener(d.producto_id).descontar_stock(d.cantidad)
        self.productos.guardar()
        return super().eliminar(id_registro)

    def orden_compra(self, id_compra):
        compra = self.obtener(id_compra)
        if compra is None:
            return None
        proveedor = self.proveedores.obtener(compra.proveedor_id)
        texto = f'ORDEN DE COMPRA #{compra.id}   fecha: {compra.fecha}\n'
        texto += f'Proveedor: {proveedor.etiqueta() if proveedor else "Eliminado"}\n' + '-' * 45 + '\n'
        texto += '\n'.join('  ' + str(d) for d in compra.detalles)
        return texto + f'\n' + '-' * 45 + f'\nTOTAL: ${compra.total:.2f} ({compra.cantidad_items} ítems)'

    def compras_de_proveedor(self, proveedor_id):
        return [x for x in self.lista if x.proveedor_id == proveedor_id]
