import json
from pathlib import Path

class GestorJSON:
    def __init__(self, archivo):
        self.archivo = Path(__file__).resolve().parent.parent / archivo

    def leer(self):
        if not self.archivo.exists():
            return []
        with self.archivo.open(encoding='utf-8') as archivo:
            return json.load(archivo)

    def guardar(self, datos):
        self.archivo.parent.mkdir(parents=True, exist_ok=True)
        with self.archivo.open('w', encoding='utf-8') as archivo:
            json.dump(datos, archivo, indent=4, ensure_ascii=False)
