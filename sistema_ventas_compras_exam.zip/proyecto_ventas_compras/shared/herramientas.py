def imprimir_titulo(texto):
    print('\n' + '=' * 48)
    print(texto.center(48))
    print('=' * 48)

def imprimir_exito(texto):
    print('✓', texto)

def imprimir_error(texto):
    print('ERROR:', texto)

def imprimir_info(texto):
    print(texto)

def confirmar(texto='¿Confirmar? (s/n): '):
    return input(texto + ' ').strip().lower() in ('s', 'si', 'sí')
