"""Menú de consola para Clientes, Productos, Ventas, Proveedores y Compras."""
from shared.herramientas import imprimir_titulo, imprimir_exito, imprimir_error, imprimir_info, confirmar
from views import ClienteController, ProductoController, VentaController, ProveedorController, CompraController


class Menu:
    def __init__(self):
        self.clientes = ClienteController()
        self.productos = ProductoController()
        self.ventas = VentaController(self.clientes, self.productos)
        # EXAMEN 13: los mismos productos deben usarse en ventas y compras.
        self.proveedores = ProveedorController()
        self.compras = CompraController(self.proveedores, self.productos)

    def pausa(self):
        input('\nPresione Enter para continuar...')

    def pedir_entero(self, texto):
        try:
            return int(input(texto))
        except ValueError:
            return None

    def mostrar_resultado(self, exito, mensaje):
        (imprimir_exito if exito else imprimir_error)(mensaje)

    def ejecutar(self):
        while True:
            imprimir_titulo('SISTEMA DE VENTAS Y COMPRAS')
            print('  1. Clientes\n  2. Productos\n  3. Ventas\n  4. Proveedores\n  5. Compras\n  0. Salir\n')
            opcion = input('Opción: ').strip()
            controladores = {'1': self.clientes, '2': self.productos, '3': self.ventas,
                             '4': self.proveedores, '5': self.compras}
            if opcion in controladores:
                self.menu_crud(controladores[opcion])
            elif opcion == '0':
                imprimir_info('¡Hasta luego!')
                break
            else:
                imprimir_error('Opción no válida')
                self.pausa()

    def menu_crud(self, controlador):
        while True:
            imprimir_titulo(controlador.nombre.upper() + 'S')
            print(f'  1. Crear {controlador.nombre}')
            print('  2. Ver todos\n  3. Buscar\n  4. Ver por ID\n  5. Actualizar\n  6. Eliminar')
            if controlador == self.ventas:
                print('  7. Ver factura')
            elif controlador == self.compras:
                print('  7. Ver orden de compra')
            print('  0. Volver\n')
            opcion = input('Opción: ').strip()
            if opcion == '0':
                break
            elif opcion == '1':
                if controlador == self.ventas:
                    self.crear_venta()
                elif controlador == self.compras:
                    self.crear_compra()
                else:
                    self.crear(controlador)
            elif opcion == '2':
                self.ver_todos(controlador)
            elif opcion == '3':
                self.buscar(controlador)
            elif opcion == '4':
                self.ver_por_id(controlador)
            elif opcion == '5':
                self.actualizar(controlador)
            elif opcion == '6':
                self.eliminar(controlador)
            elif opcion == '7' and controlador == self.ventas:
                self.ver_factura()
            elif opcion == '7' and controlador == self.compras:
                self.ver_orden_compra()
            else:
                imprimir_error('Opción no válida')
                self.pausa()

    def crear(self, controlador):
        imprimir_titulo('CREAR ' + controlador.nombre.upper())
        datos = {campo: input(f'{campo.capitalize()}: ') for campo in controlador.campos}
        self.mostrar_resultado(*controlador.crear(datos))
        self.pausa()

    def ver_todos(self, controlador):
        imprimir_titulo(controlador.nombre.upper() + 'S')
        for objeto in controlador.leer():
            print(' ', objeto)
        imprimir_info(f'Total: {len(controlador.leer())}')
        self.pausa()

    def buscar(self, controlador):
        imprimir_titulo('BUSCAR ' + controlador.nombre.upper())
        for objeto in controlador.buscar(input('Buscar: ')):
            print(' ', objeto)
        self.pausa()

    def ver_por_id(self, controlador):
        id_registro = self.pedir_entero('ID: ')
        objeto = controlador.obtener(id_registro)
        if objeto is None:
            imprimir_error('No encontrado')
        else:
            for campo, valor in objeto.a_diccionario().items():
                print(f'{campo}: {valor}')
        self.pausa()

    def actualizar(self, controlador):
        if controlador in (self.ventas, self.compras):
            imprimir_error(f'Las {controlador.nombre}s registradas no se pueden modificar')
            self.pausa()
            return
        id_registro = self.pedir_entero('ID: ')
        objeto = controlador.obtener(id_registro)
        if objeto is None:
            imprimir_error('No encontrado')
            self.pausa()
            return
        print('Deje vacío un campo para conservarlo.')
        cambios = {}
        for campo in controlador.campos:
            anterior = getattr(objeto, campo)
            nuevo = input(f'{campo.capitalize()} [{anterior}]: ').strip()
            if nuevo:
                cambios[campo] = nuevo
        self.mostrar_resultado(*controlador.actualizar(id_registro, cambios))
        self.pausa()

    def eliminar(self, controlador):
        id_registro = self.pedir_entero('ID: ')
        objeto = controlador.obtener(id_registro)
        if objeto is None:
            imprimir_error('No encontrado')
        elif confirmar(f'¿Eliminar {objeto.etiqueta()}? (s/n):'):
            self.mostrar_resultado(*controlador.eliminar(id_registro))
        else:
            imprimir_info('Cancelado')
        self.pausa()

    def _pedir_items(self, compra=False):
        imprimir_info('Productos disponibles:')
        for producto in self.productos.leer():
            print(' ', producto)
        items = []
        while True:
            producto_id = self.pedir_entero('ID producto (0 termina): ')
            if producto_id == 0:
                break
            if producto_id is None:
                imprimir_error('ID inválido')
                continue
            cantidad = self.pedir_entero('Cantidad: ')
            if cantidad is None or cantidad <= 0:
                imprimir_error('Cantidad inválida')
                continue
            item = {'producto_id': producto_id, 'cantidad': cantidad}
            if compra:
                item['costo_unitario'] = input('Costo unitario (ej. 8.50): ').strip()
            items.append(item)
        return items

    def crear_venta(self):
        imprimir_titulo('REGISTRAR VENTA')
        cliente_id = self.pedir_entero('ID del cliente: ')
        if cliente_id is None:
            imprimir_error('ID inválido')
        else:
            items = self._pedir_items()
            self.mostrar_resultado(*self.ventas.crear({'cliente_id': cliente_id, 'items': items}))
        self.pausa()

    def crear_compra(self):
        imprimir_titulo('REGISTRAR COMPRA')
        proveedor_id = self.pedir_entero('ID del proveedor: ')
        if proveedor_id is None:
            imprimir_error('ID inválido')
        else:
            items = self._pedir_items(compra=True)
            self.mostrar_resultado(*self.compras.crear({'proveedor_id': proveedor_id, 'items': items}))
        self.pausa()

    def ver_factura(self):
        texto = self.ventas.factura(self.pedir_entero('ID de venta: '))
        print(texto if texto else 'No existe esa venta')
        self.pausa()

    def ver_orden_compra(self):
        texto = self.compras.orden_compra(self.pedir_entero('ID de compra: '))
        print(texto if texto else 'No existe esa compra')
        self.pausa()


if __name__ == '__main__':
    try:
        Menu().ejecutar()
    except KeyboardInterrupt:
        print('\nPrograma interrumpido.')
